export default function ModDetail({ params }) {
  const { id } = params;
  return (
    <main className="p-4">
      <h1 className="text-xl font-bold">Chi tiết mod #{id}</h1>
      <img src="/demo.jpg" alt="mod" className="w-64 my-4" />
      <p>Mô tả chi tiết về mod...</p>
      <a href="#" className="bg-green-500 text-white px-4 py-2 inline-block mt-4 rounded">
        Tải về
      </a>
    </main>
  );
}
