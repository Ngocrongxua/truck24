import ModCard from "../components/ModCard";

export default function Home() {
  const mods = [
    { id: 1, title: "Skin Container Viettel", img: "/demo.jpg" },
    { id: 2, title: "Skin Xe Bus Anime", img: "/demo.jpg" }
  ];

  return (
    <main className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
      {mods.map((m) => (
        <ModCard key={m.id} mod={m} />
      ))}
    </main>
  );
}
