export default function UploadPage() {
  return (
    <main className="p-4">
      <h1 className="text-xl font-bold mb-4">Upload Mod</h1>
      <form className="flex flex-col gap-2 max-w-md">
        <input type="text" placeholder="Tên mod" className="border p-2" />
        <input type="text" placeholder="Link tải (Google Drive, Mediafire...)" className="border p-2" />
        <textarea placeholder="Mô tả" className="border p-2"></textarea>
        <button className="bg-blue-500 text-white p-2 rounded">Đăng</button>
      </form>
    </main>
  );
}
