import Link from "next/link";

export default function ModCard({ mod }) {
  return (
    <div className="border rounded-lg p-4 shadow">
      <img src={mod.img} alt={mod.title} className="w-full h-40 object-cover rounded" />
      <h2 className="text-lg font-semibold mt-2">{mod.title}</h2>
      <Link href={`/mods/${mod.id}`} className="text-blue-500 underline mt-2 block">
        Xem chi tiết
      </Link>
    </div>
  );
}
